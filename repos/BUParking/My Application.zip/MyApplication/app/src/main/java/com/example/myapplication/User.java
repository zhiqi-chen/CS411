package com.example.myapplication;

public class User {

    public String username;
    public String permit;

    public void setPermit(String permit) {
        this.permit = permit;
    }

    public String getPermit() {
        return permit;
    }

    public String getUsername() {
        return username;
    }
}
