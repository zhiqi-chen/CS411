package com.example.myapplication.ui.dashboard;

public class Permit {
    public String name;
    public String paymentFreq;
    public String userType;
    public Integer dayWeekPrice;
    public Integer springPrice;
    public Integer summerPrice;
    public Integer fallPrice;

    public String getName(){
        return name;
    }
    public String getPaymentFreq(){
        return paymentFreq;
    }
    public String getUserType() {
        return userType;
    }
    public Integer getDayWeekPrice() {
        return dayWeekPrice;
    }
    public Integer getSpringPrice() {
        return springPrice;
    }
    public Integer getSummerPrice() {
        return summerPrice;
    }
    public Integer getFallPrice() {
        return fallPrice;
    }
}

